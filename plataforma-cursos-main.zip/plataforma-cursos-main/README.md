## Trabalho

Utilizando Laravel, para rodar utilize os comandos:
`composer install`

`npm install`

`npm run build`

Copie o arquivo .env.example e renomeie para .env e configure o banco de dados.

`php artisan key:generate`

`php artisan migrate:fresh --seed`

`php artisan serve`

abra `127.0.0.1:8000` no navegador.

Admin padrão é admin@admin.com senha 123123123